[ Intructions In Installing Python Modules ]

* Extract the package or 'tar -xf <package.tar.gz>'
* Open the package folder or 'cd <packagefolder>'
* Type 'python setup.py --verbose build'
* Take a nap for a while. Then ..
* Type 'python setup.py --verbose install'

<Visit https://github.com/tuxdeflux/fsteam/modules>

