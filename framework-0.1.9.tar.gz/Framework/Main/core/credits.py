#!/usr/bin/python

import os
from colored import *
from time import *

def credits():
	print fore.BLUE+'    FSECURITY FRAMEWORK v0.1.9\n'
	print '   Founder:   tuxdeflux'
	print ' Developer:   Free Security Team'
	print 'Maintainer:   codex'+style.RESET 

	print '\n   Repos: https://github.com/tuxdeflux/fsteam'
	print ' Website: http://web.fsec.ty'
