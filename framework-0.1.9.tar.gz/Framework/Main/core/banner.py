#!/usr/bin/python

#fsecurity affiliate
from colored import *
from time import *
import time

def banner():

	print ("		 "+"_____  _            "+" _     ____				 		")
	print ("		 "+fore.BLACK+back.WHITE+"| __ \| | __ _  ___ "+style.RESET+back.BLACK+"| | __/ ___|  ___   ___ "+style.RESET)
	print ("		 "+fore.BLACK+back.WHITE+"|    /| |/ _' |/ __|"+style.RESET+back.BLACK+"| |/ /\___ \ / _ \ / __|"+style.RESET)
	print ("		 "+fore.BLACK+back.WHITE+"| __ \| | (_| | (__ "+style.RESET+back.BLACK+"|   (  ___) |  __/| (__ "+style.RESET)
	print ("		 "+fore.BLACK+back.WHITE+"|____/|_|\__,_|\___|"+style.RESET+back.BLACK+"|_|\_\|____/ \___| \___|"+style.RESET)
	print ("		 "+fore.GREEN+"	  Black Security est. 2015                		\n"+style.RESET)

	print "\t   If you're a novice, type "+('%s\"help\"%s' % (fg(1), attr(0))) +" to enlighten your brain"

	print "\t     ["+"\033[1;31mCode like a hacker and think like a fundamentalist\033[1;m"+"]\n"
	sleep(4)


