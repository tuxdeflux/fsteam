#!/usr/bin/python
import os
from colored import *
def _modules():
	print "\n\t\033[1;31mUpcoming Updates\tDescription\n\033[1;m"
	print "\t\033[1;1mSecure Shell Botnet\033[1;m\tStill researching about this one.\n\t\t\t\tTo much excitement. "
	print "\t\033[1;1mForensic Tools\033[1;m\t\tThis is very helpful for some recovery\n\t\t\t\tand research work." 
	print "\t\033[1;1mDDOS Tracker\033[1;m\t\tLet's start the hunting season. \n\t\t\t\tGood for some defensive attack."
	print "\t\033[1;1mExploitation Tools\033[1;m\tEmbed some Metasploit Framework exploit\n\t\t\t\tto automate attack.\n"

	print "\tVisit our website for some cool updates at"+fore.LIGHT_BLUE+" http://web.fsec.ty\n"+style.RESET
