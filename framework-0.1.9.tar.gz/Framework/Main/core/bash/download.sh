#!/bin/bash

echo " "
echo "[+] Downloading content. Please wait."
echo " "
wget http://www.mediafire.com/?34s9oanijz4fh6c
echo " "
