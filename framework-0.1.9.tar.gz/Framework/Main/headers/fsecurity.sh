#!/bin/bash

cd /usr/share/fsecurity && python fsecurity.py "$a"
