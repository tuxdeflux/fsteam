#!/usr/bin/bash
#
MAIN_DEBUG=0
#TWITTER: @fsecurity [FSECURITY - formerly BLACK SECURITY]
#TWITTER: @tuxdeflux [tuxdeflux@gmail.com] - Founder 
#THIS WILL CHECK IF YOU ALL HAVE  INSTALLED DEPENDENCIES
#FOR OUR FRAMEWORK. DO NOT MODIFY.


#stand alone color
rojo="\033[1;31m"
verde="\033[1;32m"
azul="\033[1;34m"
rescolor="\e[0m"

if [ $MAIN_DEBUG = 1 ]; then
	## set to /dev/stdout when in developer/debugger mode
	export main_output_device=/dev/stdout
	HOLD="-hold"
else
	## set to /dev/null when in production mode
	export main_output_device=/dev/null
	HOLD=""
fi

function conditional_clear() {
	if [[ "$main_output_device" != "/dev/stdout" ]]; then clear; fi
}

#root privileges
if ! [ $(id -u) = "0" ] 2>/dev/null; then
	echo -e "\e[1;31m[-] Error: Permission denied. No superuser privileges. "$rescolor""
	exit
fi

function checkdependencies {
	echo " "
	echo -e "\e[1;32mCHECKING DEPENDENCIES. PLEASE WAIT."$rescolor""
	echo " "
	sleep 1
	echo -ne "Python 2.7		> "
	if ! [ -f /usr/lib/python2.7/compiler/ast.py ]; then	#location of colred module
		echo -e "\e[1;31mNot installed. Please install.  "$rescolor""
		decide=1
#colored/back.py

	else
		echo -e "\e[1;32mModule found. Skipping."$rescolor""
	fi


	sleep 1
	echo -ne "Colored Python Module	> "
	if ! [ -f /usr/local/lib/python2.7/dist-packages/colored/back.py ]; then	#location of colred module
		echo -e "\e[1;31mNot installed. Please install.  "$rescolor""
		decide=1
#colored/back.py

	else
		echo -e "\e[1;32mModule found. Skipping."$rescolor""
	fi
	sleep 1

	echo -ne "NMAP Python Module	> "
	if ! [ -f /usr/local/lib/python2.7/dist-packages/nmap/nmap.pyc ]; then	
		echo -e "\e[1;31mNot installed. Please install."$rescolor""
		decide=1
	else
		echo -e "\e[1;32mModule found. Skipping."$rescolor""
	fi
	sleep 1
	echo -ne "Mechanize Python Module	> "
	if ! [ -f /usr/lib/python2.7/dist-packages/mechanize/_beautifulsoup.py ]; then	#location of colred module
		echo -e "\e[1;31mNot installed. Please install."$rescolor""
		decide=1
	else
		echo -e "\e[1;32mModule found. Skipping."$rescolor""
	fi
	sleep 1

	echo -ne "Scapy Python Module	> "
	if ! [ -f /usr/lib/python2.7/dist-packages/scapy/all.py ]; then	#location of colred module
		echo -e "\e[1;31mNot installed. Please install."$rescolor""
		decide=1
	else
		echo -e "\e[1;32mModule found. Skipping."$rescolor""
	fi
	sleep 1
	echo -ne "Apache Web Server	> "
	if ! [ -f /etc/apache2/apache2.conf ]; then	#location of colred module
		echo -e "\e[1;31mNot installed. Please install."$rescolor""
		decide=1
	else
		echo -e "\e[1;32mModule found. Skipping."$rescolor""
	fi
	
	sleep 1
		echo -ne "Bluetooth Modules	> "
	if ! [ -f /usr/lib/python2.7/dist-packages/bluetooth/bluez.py ]; then	#location of colred module
		echo -e "\e[1;31mNot installed. Please install."$rescolor""
		decide=1
	else
		echo -e "\e[1;32mModule found. Skipping."$rescolor""
	fi
	
	sleep 1
	echo ""
}

echo ""
echo "For module visit https://github.com/tuxdeflux/fsteam/modules"

checkdependencies

if [ $MAIN_DEBUG != 1 ]; then
	sudo python fsecurity.py
fi
