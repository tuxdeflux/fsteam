
[Free Security Team (c) 2016]

** CHANGELOG Free Security Framework

10. [November 5, 2016] - Free Security Framework v0.1.9-codefish
   * latest framework release
   * added bluetooth modules
   * added dependencies on Dependencies folder
   * bug fixes
   * added show device command

09. [October 14, 2016] - Free Security Framework v0.1.8-codefish
   * added new commands
   * removed unneccesary commands

08. [September 20, 2016] - Free Security Framework v0.1.7-nostalgia
   * added colored python module
   * redesigned text
   * bug fixes colored module 
   * added fst banner

07. [July 2016] - Free Security Framework v0.1.6-nostalgia
   * added upgrade.py
   * added network modules
   * bug fixes
   * added dns-enum.sh

06. [May 14, 2016] - Free Security Framework v0.1.5-coffeemaster
   * release on mediafire.com
   * decided to remove credit card sniffer

05. [April 2016] - Free Security Framework v0.1.4-coffeemaster
   * added web modules
   * bug fixes
   * coded install.sh to check dependencies

04. [March 2016] - Free Security Framework v0.1.3-debug
   * dependency issues, recoded
   * added header.py
   * added server module

03. [January 2016]  - Free Security Framework v0.1.2-evee
   * added network modules
   * bug fixes
   * beta testing
   * added new banner 
 
02. [January 2016]  - Free Security Framework v0.1.1-alpha
   * bug fixes
   * added file cracker

01. [December 2015] - Free Security Framework v0.1.0-alpha
   * initial local release christmas eve 
   * python version 2.7
   * beta testing

