[Free Security Framework v0.1.9]
[Free Security Team (c) 2016]

* For v0.2.0 release and updates
	-  Apache2 Server integration
	-  Denial of Service tracker
	
* Other plans
	-  Forensic tools
	-  Secure shell botnet
	-  Exploitaion tools
